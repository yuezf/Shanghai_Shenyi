import numpy as np
import pandas as pd
from arch import arch_model

def movingWindomVol(array, window=250, discount_or_not=False, threshold=0.6):
    vol = np.std(np.diff(np.log(array[-window:]))) * np.sqrt(250)

    if discount_or_not is False:
        return vol
    else:
        if vol > threshold:
            return vol ** 0.5 + threshold - threshold ** 0.5
        else:
            return vol


def ewmVol(array, window=500):
    span = int(window / 2)
    vol = np.std(np.diff(np.log(array[-window:]))) * np.sqrt(250)
    adj_vol = list(pd.Series(vol).ewm(span=span).mean())[-1]
    return adj_vol

#
def garchVol(array, window=250):
    returns = np.diff(np.log(array[-window:]))
    am = arch_model(returns, vol='Garch', p=1, o=0, q=1, dist='Normal')
    res = am.fit(disp='off')
    forecast = res.forecast(reindex=False)
    vol = forecast.variance.values[-1][0]**0.5*np.sqrt(250)
    return vol