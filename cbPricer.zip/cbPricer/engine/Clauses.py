import numpy as np
from engine.Base import _pv

# Path slicer


def _sliceInMC(array, point, length):
    # 将路径切片，分析条款触发情况
    # 从point往前切片长度为length的array，若length > point，则截取可合法获得的最大长度
    return array[int(max([0, point - length])):int(point)]


def _isRecall(arrStockPrice, arrTimeSeries, recallPeriod, recallThreashold, recallLevel):
    validTime = np.array(arrTimeSeries) < recallPeriod  # 若剩余时间小于5.5，说明此时可以转股，则当日时间合法
    validPrice = arrStockPrice > recallLevel  # 若当期股价高于回售价（i.e., 130%*转股价），当日价格合法

    return True if np.sum(validTime * validPrice) >= recallThreashold else False  # 若合法的总天数大于15，则赎回触发，返回True


def _isResell(arrStockPrice, arrTimeSeries, resellThreashold, resellObsInterval, resellLevel):
    validTime = np.array(arrTimeSeries) < resellObsInterval  # 处于最后两年，则合法
    validPrice = arrStockPrice < resellLevel  # 股价低于70%*转股价，则合法

    return True if np.sum(validTime * validPrice) >= resellThreashold else False  # 若合法的总天数大于30，则回售触发，返回True


def _isReset(arrStockPrice, resetThreashold, resetObsInterval, resetLevel):
    validPrice = arrStockPrice < resetLevel  # 股价低于85%*转股价，则合法

    return True if np.sum(1 * validPrice) >= resetThreashold else False


def _pvCashFlowMC(thisRowEndTime, thisRowValue, dictCF, r):  # 折现蒙特卡洛模拟每一条路径的支付

    cfT = [thisRowEndTime]
    cf = [thisRowValue]

    for time in dictCF:
        if time / 250 < thisRowEndTime:
            cfT.append(time / 250)
            cf.append(dictCF[time])

    return _pv(cf, cfT, r)


def _processRecall(term, row, i, arrTimeSeries):
    recallPeriod = term['Recall'][0]  # 5.5
    recallThreashold = term['Recall'][1]  # 15
    recallObsInterval = term['Recall'][2]  # 30
    recallLevel = term['Recall'][3] / 100 * term['ConvPrice']  # 130

    if row[i] > recallLevel:  # 如果当期模拟价格大于130%*转股价，观察连续30交易日正股股价，以判断是否触发赎回

        sliceArrStockPrice = _sliceInMC(row, i, recallObsInterval)
        sliceArrTimeSeries = _sliceInMC(arrTimeSeries, i, recallObsInterval)

        isRecallTriggered = _isRecall(sliceArrStockPrice, sliceArrTimeSeries, recallPeriod, recallThreashold,
                                      recallLevel)

        if isRecallTriggered:
            thisRowEndTime = i / 250
            thisRowValue = max((100 / term['ConvPrice']) * row[i], 100)  # 若赎回触发，则该路径上的支付为：(100/转股价)*正股股价
            # TODO: 100 -> par + accured interest
        else:
            thisRowEndTime = None
            thisRowValue = None

        return isRecallTriggered, thisRowEndTime, thisRowValue

    else:
        return [None] * 3


def _processResell(term, row, i, arrTimeSeries):
    resellBegin = term['Resell'][0]  # 回售只从最后2年开始
    resellThreashold = term['Resell'][1]  # 至少30 out of 30观察日
    resellObsInterval = term['Resell'][2]  # 观察期连续30日
    resellLevel = term['Resell'][3] / 100 * term['ConvPrice']  # 股价低于70%*转股价
    resellPrice = term['Resell'][4]  # 按103%*par回售

    if row[i] < resellLevel:
        sliceArrStockPrice = _sliceInMC(row, i, resellObsInterval)
        sliceArrTimeSeries = _sliceInMC(arrTimeSeries, i, resellObsInterval)

        isResellTriggered = _isResell(sliceArrStockPrice, sliceArrTimeSeries,
                                      resellThreashold, resellObsInterval, resellLevel)

        if isResellTriggered:
            thisRowEndTime = i / 250
            thisRowValue = max((100 / term['ConvPrice']) * row[i], resellPrice)
        else:
            thisRowEndTime = None
            thisRowValue = None

        return isResellTriggered, thisRowEndTime, thisRowValue

    else:
        return [None] * 3


def _processReset(term, row, i, arrTimeSeries):
    resetThreashold = term['Reset'][0]  # 20个观察日
    resetObsInterval = term['Reset'][1]  # out of 30
    resetLevel = term['Reset'][2] / 100 * term['ConvPrice']  # 股价低于85%*转股价

    if row[i] < resetLevel:

        sliceArrStockPrice = _sliceInMC(row, i, resetObsInterval)

        isResetTriggered = _isReset(sliceArrStockPrice, resetThreashold, resetObsInterval, resetLevel)

        if isResetTriggered:

            # 修正转股价 >= max(last close, mean(last 20 days close))
            resetPrice = np.max([np.mean(sliceArrStockPrice), sliceArrStockPrice[-1]])

            return isResetTriggered, resetPrice
        else:
            return None, None

    else:
        return None, None