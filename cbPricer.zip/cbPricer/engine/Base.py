import numpy as np
import datetime as dt
import pandas as pd
from scipy.stats import norm
import matplotlib.pyplot as plt

def _cashFlowCalc(termCoupon, dtMaturityDate, dtNowDate):
    # 将到期日和现在的时间翻译成datetime格式
    # Translate maturity and now date into python datetime

    # 计算剩余期限（年）
    # Compute remaining tenor
    numPtmYears = (dtMaturityDate - dtNowDate).days / 365

    # 计算还有哪些票息、本金未支付
    # Compute the unpaid coupon and principal
    n = len(termCoupon)
    numDig, numRound = np.modf(numPtmYears)  # Dig(ital)为年，Round为小数部分
    numPayment = int(np.min([numRound + 1, n]))

    # List the all future cash flows and also the time from today that cash flow should be paid
    cashFlow = termCoupon[-numPayment:]  # 所有要支付的现金流amount list eg. [1.5, 106.6]
    cashFlowTime = np.arange(numPayment) + numDig  # 所有未来要支付现金流距离今天的支付时间 eg. [0.08493151, 1.08493151]

    return cashFlow, cashFlowTime


# Present value calculator
def _pv(cashFlow, cashFlowTime, r):
    pv = 0

    for t, cash in enumerate(cashFlow):  # 折现现金流
        pv += cash / ((1 + r) ** cashFlowTime[t])

    return pv


# Bond price calculator
def bondPrice(termCoupon, strMaturityDate, strNowDate, r):
    # 计算债底价值
    cashFlow, cashFlowTime = _cashFlowCalc(termCoupon, strMaturityDate, strNowDate)
    price = _pv(cashFlow, cashFlowTime, r)

    return price


# Convert the coupon-date info into annual Python dict
def _cashFlowDict(termCoupon, MaturityDate, NowDate):
    cashFlow, cashFlowTime = _cashFlowCalc(termCoupon, MaturityDate, NowDate)
    dictCF = {}

    for i in range(len(cashFlow)):
        dictCF[round(cashFlowTime[i] * 250)] = cashFlow[i]

    return dictCF  # eg. {47: 1.5, 297: 106.6}


# Not used in the following pricer
def cashFlowGenerator(dictCF, tDate):
    return dictCF[tDate] if tDate in dictCF else 0

