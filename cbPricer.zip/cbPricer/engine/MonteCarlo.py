from engine.Base import _cashFlowDict
from engine.Clauses import _processReset, _processRecall, _pvCashFlowMC, _processResell
from engine.Clauses import *
import numpy as np
import datetime as dt
import pandas as pd
import tqdm
from scipy.stats import norm
import matplotlib.pyplot as plt

# Simulate stock price, return a numSimulation*numNodes stock price matrix



def _monteCarlo(stock, vol, r, numNodes, numSimulation=10000, antithetic=False):
    arrStock = np.ones([numSimulation, numNodes + 1]) * stock
    dt = 1 / 250

    rc = np.log(1 + r)

    if antithetic:
        randMatrix = np.random.randn(int(numSimulation / 2), numNodes)
        randMatrix = np.vstack([randMatrix, -randMatrix])

    else:
        randMatrix = np.random.randn(numSimulation, numNodes)

    arrSimulation = np.cumprod(np.exp((rc - 0.5 * vol ** 2) * dt + vol * np.sqrt(dt) * randMatrix), axis=1)
    arrStock[:, 1:] = arrSimulation
    arrStock *= stock

    return arrStock


# Convertible pricer using MC
def cbPricingMC(stock, term, now, vol, r, numSimulation=10000, reset=True, recall=True, resell=True):
    dictCF = _cashFlowDict(term['Coupon'], term['Maturity'], now)

    initConvPrice = term['ConvPrice']

    numNodes = int(max(dictCF))

    # 每一天距离到期日的时间（年）
    # Get remaining dates (in year) in an iterable
    arrTimeSeries = [(numNodes - i) / 250 for i in range(numNodes)]

    # Get simulated stock price
    arrMC = _monteCarlo(stock, vol, r, numNodes, numSimulation, antithetic=False)

    v = []

    # 遍历每一条路径
    # Walk through all paths
    for row in arrMC:

        term['ConvPrice'] = initConvPrice  # 复原转股价

        # 遍历该路径上的每一个交易日
        # Walk through all simulated stock prices on that path
        for i in range(numNodes):

            # 判断是否触发下修
            # Test if that day triggers donwside fix/reset
            if reset:
                isResetTriggered, resetPrice = _processReset(term, row, i, arrTimeSeries)

                if isResetTriggered:
                    term['ConvPrice'] = resetPrice

            # 判断是否触发赎回
            # Test if that day triggers recall
            if recall:
                isRecallTriggered, thisRowEndTime, thisRowValue = _processRecall(term, row, i, arrTimeSeries)

                if isRecallTriggered:
                    v.append(_pvCashFlowMC(thisRowEndTime, thisRowValue, dictCF, r))
                    break

            # 判断是否触发回售
            # Test if that day triggers resell
            if resell:
                isResellTriggered, thisRowEndTime, thisRowValue = _processResell(term, row, i, arrTimeSeries)

                if isResellTriggered:
                    v.append(_pvCashFlowMC(thisRowEndTime, thisRowValue, dictCF, r))
                    break

            # 若无触发赎回、回售、下修等附加条款，计算到期价值
            # If all clauses won't get triggered, compute the expiry payoff at the last day
            if i == (numNodes - 1):
                thisRowEndTime = numNodes / 250
                thisRowValue = np.max([100 / term['ConvPrice'] * row[-1], term['Coupon'][-1]])  # 则转债价值为…
                v.append(_pvCashFlowMC(thisRowEndTime, thisRowValue, dictCF, r))

    return np.mean(v)