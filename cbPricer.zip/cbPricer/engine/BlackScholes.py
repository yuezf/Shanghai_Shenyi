from engine.Base import *
import numpy as np
import datetime as dt
import pandas as pd
from scipy.stats import norm
import matplotlib.pyplot as plt

# Black Scholes pricer
def blackScholes(s, x, t, vol, r):
    d1 = (np.log(s / x)) + (r + 0.5 * vol ** 2 * t) / (np.sqrt(t) * vol)
    d2 = d1 - vol * np.sqrt(t)
    c = s * norm.cdf(d1) - x * np.exp(-r * t) * norm.cdf(d2)

    return c


# Convertible BS pricer
def cbPricingBlackScholes(stock, term, dtNowDate, vol, r):
    # 计算债底
    # Compute the bond price
    straightBondValue = bondPrice(term['Coupon'], term['Maturity'], dtNowDate, r)

    # 计算转股看涨期权
    # Compute the call option price. The call option is the right to convert the convertible into shares at conversion price
    s = stock
    x = term['ConvPrice'] * term['Coupon'][-1] / 100

    dtMaturityDate = term['Maturity']

    t = (dtMaturityDate - dtNowDate).days / 365

    call = blackScholes(s, x, t, vol, np.log(1 + r) * 100 / term['ConvPrice'])

    # 转债价 = 债底 + 看涨
    # Convertible price = bond + call
    return straightBondValue + call
