'''
Utils
'''
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import re


# 从新浪财经下载票面利率
# Download coupon data from Sina finance. Tushare isn't offering all data we needed
def getCoupon(ticker):
    options = Options()

    # Download at here: https://chromedriver.chromium.org/
    # Choose the version matches your own Chrome
    # 在此修改chromedriver路径; Revise your chromedriver path here
    driver = webdriver.Chrome(executable_path=rf'./chromedriver.exe', options=options)

    url = rf'https://money.finance.sina.com.cn/bond/info/{ticker}.html'
    driver.get(url)
    time.sleep(3)

    target = driver.find_element_by_id('intro')
    couponStr = target.text
    driver.quit()
    coupon = re.findall(r"[-+]?\d*\.\d+|\d+", couponStr)
    coupon = [float(c) for c in coupon]

    return coupon