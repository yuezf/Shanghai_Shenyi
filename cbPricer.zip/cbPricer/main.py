from pricer.pricer import *
import warnings
warnings.filterwarnings("ignore")

def main():

    cb_ticker = '110041.SH'
    eq_ticker = '600863.SH'


    termCB = {'ConvPrice': 0,  # 转股价
              'Maturity': 0,  # 到期日
              'ConvertStart': 5.5,  # 转股期，5.5 implies 到期前5.5年
              'Coupon': None,  # 票息（%）
              'Recall': [5.5, 15, 30, 130],  # 赎回条款
              'Resell': [2, 30, 30, 70, 100],  # 回售条款
              'Reset': [15, 30, 90]  # 下修条款
              }

    cbPricer(eq_ticker, cb_ticker, termCB, numSimulation=1000, reset=True, recall=True, resell=False)
if __name__ == '__main__':
    main()

