import tushare as ts
import tqdm as tqdm
from utils.WebScrapper import *
from params.volatility import *
from engine.BlackScholes import *
from engine.MonteCarlo import *


ts.set_token('f5cd5ac60f1cd9a51a12fa6d5980978ab630fc8f9fc8004e736ef666')
pro = ts.pro_api()

def cbPricer(eq_ticker, cb_ticker, termCB, numSimulation=10000, reset=True, recall=True, resell=True):


    ts_field_params = 'ts_code,bond_full_name,bond_short_name,cb_code,stk_code,' \
                      'stk_short_name,maturity,par,issue_price,issue_size,remain_size,' \
                      'value_date,maturity_date,rate_type,coupon_rate,add_rate,pay_per_year,' \
                      'list_date,delist_date,exchange,conv_start_date,conv_end_date,' \
                      'first_conv_price,conv_price,rate_clause,put_clause,maturity_put_price,' \
                      'call_clause,reset_clause,conv_clause,guarantor,guarantee_type,' \
                      'issue_rating,newest_rating,rating_comp'

    cb_ts = pro.cb_daily(ts_code=cb_ticker).sort_values(by=['trade_date']).set_index('trade_date')
    cb_ts.index = pd.to_datetime(cb_ts.index)

    eq_ts = pro.daily(ts_code=eq_ticker).sort_values(by=['trade_date']).set_index('trade_date')
    eq_ts.index = pd.to_datetime(eq_ts.index)



    # 完善termCB信息
    getCouponTicker = f'{cb_ticker[-2:]}{cb_ticker[:6]}'
    termCB['Coupon'] = getCoupon(getCouponTicker)

    basics = pro.cb_basic(ts_code=cb_ticker, fields=ts_field_params)
    termCB['ConvPrice'] = float(basics.first_conv_price)
    termCB['Coupon'][-1] = float(basics.maturity_put_price)

    cb_price_chg = pro.cb_price_chg(ts_code=cb_ticker).set_index('change_date', drop=True)
    cb_price_chg.index = pd.to_datetime(cb_price_chg.index)
    cb_price_chg = cb_price_chg.fillna(value=termCB['ConvPrice'])

    maturity = basics.maturity_date[0]
    maturity = dt.datetime.strptime(maturity, '%Y-%m-%d')
    termCB['Maturity'] = maturity

    simulationFromBS = []
    simulationFromMC = []

    convPriceChangeDate = cb_price_chg.index

    for date in tqdm.tqdm(cb_ts.index[:-1]):

        if date in convPriceChangeDate:
            termCB['ConvPrice'] = cb_price_chg.loc[date, 'convertprice_aft']

        termCB_Copy = termCB.copy()

        stockPriceIdx = eq_ts.index.get_loc(date, 'ffill')
        todayStockPrice = eq_ts.iloc[stockPriceIdx]['close']

        array = eq_ts.iloc[:stockPriceIdx]['close'].to_list()

        eq_vol = garchVol(array)  # 观察一个季度的波动率？

        bs = cbPricingBlackScholes(todayStockPrice, termCB_Copy, date, vol=eq_vol, r=0.06)
        mc = cbPricingMC(todayStockPrice, termCB_Copy, date, vol=eq_vol, r=0.06, numSimulation=numSimulation,
                         reset=False, recall=True, resell=True)

        simulationFromMC.append(mc)
        simulationFromBS.append(bs)

    # 绘图
    df = pd.DataFrame(np.stack([list(cb_ts.close[:-1]), simulationFromMC, simulationFromBS], axis=1),
                  index=cb_ts.index[:-1],
                  columns=[f'{cb_ticker}', 'mc', 'bs'])

    df.plot(figsize=(15, 10))
    plt.show()